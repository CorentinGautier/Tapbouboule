package corp.corenting.jeux;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class finDeJeu extends AppCompatActivity {

    private int bestScore;
    private int newScore;
    TextView textViewNewScore;
    TextView textViewBestScore;
    private String MY_FILE_NAME;
    SharedPreferences preference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fin_de_jeu);
        initPreferenceManager();
            CompareScore();

            textViewBestScore = (TextView) findViewById(R.id.textViewBestScore);
            String j = Integer.toString(bestScore);
            textViewBestScore.setText(j);

            textViewNewScore = (TextView) findViewById(R.id.textViewNewScore);
            String i = Integer.toString(newScore);
            textViewNewScore.setText(i);

            preference.edit().putInt("bestScoreJeu1", bestScore).apply();
                    }

        public void CompareScore () {
            newScore = ActivityJeu1.getScoreFinal();
            if (newScore > bestScore) {
                bestScore = newScore;
            }
        }
        private void initPreferenceManager(){
        preference = PreferenceManager.getDefaultSharedPreferences(this);
        bestScore = preference.getInt("bestScoreJeu1", 0);
        }

        public void Retour (View v){//retour menuPrincipal
            Intent intent = new Intent(this, MainActivity.class); // l'activité où on est vers la prochaine
            startActivity(intent);
            this.finish();
        }
}
