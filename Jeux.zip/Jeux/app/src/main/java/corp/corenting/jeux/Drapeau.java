package corp.corenting.jeux;

import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class Drapeau {

    int coordCentreX, coordCentreY;
   float largeurImage = 200, hauteurImage = 200;;
   private ImageView image ;
    MainActivity fenetreJeuDeplacement;
   boolean fin;


    public Drapeau(MainActivity fenetreJeu1, float x, float y, boolean fin){
        coordCentreX=(int) (x+(largeurImage/2.0)) ;
        fenetreJeu1 = fenetreJeuDeplacement ;
        image = new ImageView(fenetreJeu1);
        image.setBackgroundResource(R.drawable.drapeauarrive);
        coordCentreY=(int) (x+(hauteurImage/2.0)) ;
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams((int)largeurImage, (int) hauteurImage);
        image.setLayoutParams(params);
        fin = false;
        image.setX(x);
        image.setY(y - hauteurImage);
        fenetreJeuDeplacement.addVie;

    }

    public boolean arriveSurDrapeau(float y) {
        if ((image.getY() < y) && (y < image.getY() + hauteurImage / 2)) {
            fin = true;
        } else {
            fin = false;
        }
        return false;
    }
    /*
    public boolean toucher(int x, int y){
        if(voiture.getX()==Drapeau.getxDrapeau()&& voiture.getY()==unDrapeau.getyDrapeau()){
            return true;
        }else {
            return false;
        }
    }
*/

}
