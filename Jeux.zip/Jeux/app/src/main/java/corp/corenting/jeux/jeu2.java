package corp.corenting.jeux;

import android.content.Intent;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class jeu2 extends AppCompatActivity implements GestureDetector.OnGestureListener {

    RelativeLayout fenetreJeu1;
    //création des boules de couleurs
    public List<ImageButton> listDeBallBleu = new ArrayList<>();
    public List<ImageButton> listDeBallVerte = new ArrayList<>();
    private List<ImageButton> listDeBallRouge;

    //compteur de point
    public int compteurBalle;
    TextView CompteurPoint;
    private static int scoreFinal ;

    //timer
    private Button countDownButton;
    private CountDownTimer countDownTimer;
    private TextView CountDownTexte;
    private long tempsRestant =10; // 10 sec
    private boolean timerRunning;

    TextView textViewTest;

    Thread Compteur ;
    private final String PROGRESS="textViewTestId";

    //L'AtomicBoolean qui gère la destruction du Thread en arrière plan
    AtomicBoolean isRunning = new AtomicBoolean(false);
    //     L'AtomicBoolean qui gère la mise en pause du Thread en arrière plan
    AtomicBoolean isPausing = new AtomicBoolean(false);

    //gestion du deplacement d'objet
    GestureDetector gestureDetector;
    private float decalageX;
    private float decalageY;
    static final int SWIPE_MIN_DISTANCE = 60;
    static final int SWIPE_THRESHOLD_VELOCITY = 100;

    //ajout de l'objet voiture
    private ImageButton voiture;
    private final  int XVOITURE = 50;
    private final  int YVOITURE = 50;

    //ajout de l'objet drapeau
    private ImageButton drapeau;
    private Drapeau unDrapeau ;


    // creation de l'activite
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activit1_main);

        //deplacement d'objet avec le tactile
        gestureDetector = new GestureDetector(this,this);

        // ajout des balles
        fenetreJeu1 = findViewById(R.id.fenetreJeu);

        //association
        CountDownTexte = findViewById(R.id.CountDown_Texte);
        textViewTest = findViewById(R.id.textViewTest);

    //crée la voiture et l'initialise et la relie a la fonction pour de déplacemen
        // a supprimer lorsque cela sera dans une autre classe pour être plus objet
        /*voiture = new ImageButton(this);
        voiture.setBackgroundResource(R.drawable.voiture);
        ViewGroup.LayoutParams paramas = new ViewGroup.LayoutParams(300, 300);
        voiture.setLayoutParams(paramas);
        voiture.setY(XVOITURE);
        voiture.setX(YVOITURE);
        voiture.setOnTouchListener(touchListenerImage1);
        fenetreJeu1.addView(voiture);
*/
        //crée le drapeau de fin et l'initialise
        unDrapeau = new Drapeau(fenetreJeu1,200, 200, false);
      /*
        drapeau = new ImageButton(this);
        drapeau.setBackgroundResource(R.drawable.drapeauarrive);
        ViewGroup.LayoutParams paramas1 = new ViewGroup.LayoutParams(200, 200);
        drapeau.setLayoutParams(paramas1);
        drapeau.setY(unDrapeau.getxDrapeau());
        drapeau.setX(unDrapeau.getyDrapeau());
        fenetreJeu1.addView(drapeau);
*/
        //ajoute le nombre de boule voulu
        CompteurPoint = (TextView) findViewById(R.id.CompteurPoint);
        for (int i = 0; i < 20; i++) {
            ajouterBallBleu();
        }
        for (int i = 0; i < 20; i++) {
            ajouterBallVerte();
        }
        for (int i = 0; i < 20; i++) {
            ajouterBallRouge();
        }

    }
//se me et route dès le lancement de l'application.
    public void onStart() {
        super.onStart();
        //Comteur a 0
        compteurBalle = 0;
        //lance un thread pour pouvoir faire une verification du timer et changer d'activité lors de la fin du temps avec un handler
        Compteur = new Thread( new Runnable() {
            Message myMessage;
            Bundle messageBundle = new Bundle();
            public void run() {
                try {
                    int s = 100;
                    while (s > 0 && isRunning.get())
                    {
                        while (isPausing.get() && (isRunning.get()))
                        {
                            // Faire une pause pour soulager le CPU
                            Thread.sleep(2000);
                        }
                        s--;
                      Thread.sleep(1000);
                        myMessage = handler.obtainMessage(); // otenir un message vierge
                        //Ajouter des données à transmettre au Handler via le Bundle
                        messageBundle.putInt(PROGRESS, s);

                        //Ajouter le Bundle au message
                        myMessage.setData(messageBundle);
                        //Envoyer le message
                        handler.sendMessage(myMessage);
                    }
                }
                catch(Throwable t) {
                }
            }
        });
        textViewTest.setText("go");
        isRunning.set(true);
        isPausing.set(false);
        Compteur.start();
    }

    //Méthode appelée quand l'activité s'arrête
    public void onStop() {
        super.onStop();
        //Mise-à-jour du booléen pour détruire la Thread de background
        isRunning.set(false);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Mise-à-jour du booléen pour mettre en pause la Thread de background
        isPausing.set(true);
    }

    @Override
    protected void onResume(){
        super.onResume();
        // Mise-à-jour du booléen pour relancer la Thread de background
        isPausing.set(false);
    }

    public int getCompteurBalle() {
        return compteurBalle;
    }


    //Permet de faire foctionner le timer en meme temps que le reste de l'application
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            int nbS=msg.getData().getInt(PROGRESS);
            // Incrémenter la ProgressBar, on est bien dans la Thread de l'IHM
            textViewTest.setText(nbS+"s");
            // On peut faire toute action qui met à jour l'IHM
          if ( nbS == 0 )            {
                scoreFinal = getCompteurBalle();
                textViewTest.setText("FIN");
                changeActivity();
            }

        }
    };

    private void changeActivity() {
        Intent intent = new Intent(this, finDeJeu.class); // l'activité où on est vers la prochaine
        startActivity(intent);
        this.finish();
    }


    @Override
    public void onWindowFocusChanged(boolean hasfocus) {
        super.onWindowFocusChanged(hasfocus);
        int[] coordonneesAbsolutsFenetrePrincipal = {0,0};
    fenetreJeu1.getLocationOnScreen(coordonneesAbsolutsFenetrePrincipal);
    decalageX=fenetreJeu1.getX() - coordonneesAbsolutsFenetrePrincipal[0];
    decalageY=fenetreJeu1.getY()-coordonneesAbsolutsFenetrePrincipal[1];
        }

    //ajoute les balles bleu et permet de les supprimer et incremnter le compteur lors d'une pressiosn
    public void ajouterBallBleu() {
        listDeBallBleu = new ArrayList<>();
        ImageButton ballBleu = new ImageButton(this);
        ballBleu.setBackgroundResource(R.drawable.rondbleu);
        ViewGroup.LayoutParams paramas = new ViewGroup.LayoutParams(100, 100);
        ballBleu.setLayoutParams(paramas);
        //positionne aléatoirement l'image en fontion de la taille de l'écran
        DisplayMetrics metriques = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metriques);
        int hauteur = metriques.heightPixels;
        int largeur = metriques.widthPixels;
        ballBleu.setX((float) Math.random() * hauteur);
        ballBleu.setY((float) Math.random() * largeur);
        fenetreJeu1.addView((ballBleu));
        listDeBallBleu.add(ballBleu);
        ballBleu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fenetreJeu1.removeView(v);
                listDeBallBleu.remove(v);
                compteurBalle =compteurBalle +10;
                String j = Integer.toString(compteurBalle);
                CompteurPoint.setText(j);
            }
        });
    }

    public void ajouterBallVerte() {
        listDeBallVerte = new ArrayList<>();
        ImageButton ballVerte = new ImageButton(this);
        ballVerte.setBackgroundResource(R.drawable.rondvert);
        ViewGroup.LayoutParams paramas = new ViewGroup.LayoutParams(100, 100);
        ballVerte.setLayoutParams(paramas);
        //positionne aléatoirement l'image en fontion de la taille de l'écran
        DisplayMetrics metriques = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metriques);
        int hauteur = metriques.heightPixels;
        int largeur = metriques.widthPixels;

        ballVerte.setX((float) Math.random() * hauteur);
        ballVerte.setY((float) Math.random() * largeur);
        fenetreJeu1.addView((ballVerte));
        listDeBallVerte.add(ballVerte);
        ballVerte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fenetreJeu1.removeView(v);
                listDeBallVerte.remove(v);
                compteurBalle =compteurBalle +20;
                String j = Integer.toString(compteurBalle);
                CompteurPoint.setText(j);
            }
        });
    }


    //balle rouge
    public void ajouterBallRouge() {
        listDeBallRouge = new ArrayList<>();
        ImageButton ballRouge = new ImageButton(this);
        ballRouge.setBackgroundResource(R.drawable.rondrouge);
        ViewGroup.LayoutParams paramas = new ViewGroup.LayoutParams(100, 100);
        ballRouge.setLayoutParams(paramas);
        //positionne aléatoirement l'image en fontion de la taille de l'écran
        DisplayMetrics metriques = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metriques);
        int hauteur = metriques.heightPixels;
        int largeur = metriques.widthPixels;
        ballRouge.setX((float) Math.random() * hauteur);
        ballRouge.setY((float) Math.random() * largeur);
        fenetreJeu1.addView((ballRouge));
        listDeBallRouge.add(ballRouge);
        ballRouge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fenetreJeu1.removeView(v);
                listDeBallRouge.remove(v);
                compteurBalle =compteurBalle + 30;
                String j = Integer.toString(compteurBalle);
                CompteurPoint.setText(j);
            }
        });
    }

    public void Retour(View view) {//retour menu
        this.finish();
    }

    public static int getScoreFinal(){
        return scoreFinal;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {
    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return true;
    }

    private View.OnTouchListener touchListenerImage1 = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch(event.getAction())
            {
                case MotionEvent.ACTION_DOWN:
                    v.setX(event.getX() + v.getX()-100);
                    v.setY(event.getY() + v.getY()-100);
                    break;
                case MotionEvent.ACTION_MOVE:
                    v.setX(event.getX() + v.getX()-100);
                    v.setY(event.getY() + v.getY()-100);
                    break;
                case MotionEvent.ACTION_UP:
                    v.setX(event.getX() + v.getX()-100);
                    v.setY(event.getY() + v.getY()-100);
                    break;
            }
            return true;
        }
    };


}